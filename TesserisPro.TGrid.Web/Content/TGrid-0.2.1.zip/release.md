﻿# TGrid Releases

## 0.2.1 
 * IE9 support added
 * Add keyboard support
 * Bugfixing

## 0.1.2
 * Minor bugfixing
 * Nuget package created

## 0.1
 * Initial release all major functions are suported
 
