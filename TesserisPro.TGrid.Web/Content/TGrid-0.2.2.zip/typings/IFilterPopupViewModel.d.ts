declare module TesserisPro.TGrid {
    interface IFilterPopupViewModel {
        onOpen(options: TGrid.Options, column: TGrid.ColumnInfo): any;
        onApply(): any;
        onClear(): any;
        onClose(): any;
        getColumnInfo(): TGrid.ColumnInfo;
        onCloseFilterPopup(): any;
    }
}
