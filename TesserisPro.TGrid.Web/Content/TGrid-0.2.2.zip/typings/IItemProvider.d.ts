declare module TesserisPro.TGrid {
    interface IItemProvider {
        actionAfterAddingItem: () => void;
        actionAfterDeletingItem: () => void;
        getItems(skip: number, take: number, sort: TGrid.SortDescriptor[], filter: TGrid.FilterDescriptor, collapsedGroupFilters: TGrid.FilterDescriptor[], callback: (items: any[], firstItem: number, itemsNumber: number) => void): void;
        getTotalItemsCount(filter: TGrid.FilterDescriptor, callback: (total: number) => void): void;
        deleteItem(item: any): any;
        addItem(item: any): any;
    }
}
