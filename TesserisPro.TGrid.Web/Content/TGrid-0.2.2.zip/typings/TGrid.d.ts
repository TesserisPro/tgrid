/// <reference path="Scripts/typings/extenders.d.ts" />
/// <reference path="Options.d.ts" />
/// <reference path="IHtmlProvider.d.ts" />
/// <reference path="IItemProvider.d.ts" />
/// <reference path="knockout/KnockoutHtmlProvider.d.ts" />
/// <reference path="knockout/KnockoutFilterPopupViewModel.d.ts" />
/// <reference path="angular/AngularFilterPopupViewModel.d.ts" />
/// <reference path="angular/AngularHtmlProvider.d.ts" />
/// <reference path="angular/AngularItemViewModel.d.ts" />
/// <reference path="GroupHeaderDescriptor.d.ts" />
/// <reference path="utils.d.ts" />
/// <reference path="IFooterViewModel.d.ts" />
/// <reference path="Scripts/typings/angularjs/angular.d.ts" />
/// <reference path="Scripts/typings/knockout/knockout.d.ts" />
declare module TesserisPro.TGrid {
    class Grid {
        private parentElement;
        private targetElement;
        private rootElement;
        private headerContainer;
        private tableBody;
        private tableBodyContainer;
        private tableFooter;
        private tableHeader;
        private mobileContainer;
        private mobileHeader;
        private buisyIndicator;
        private scrollBar;
        private groupByElement;
        private filterPopUp;
        private bodyAndHeaderContainer;
        private htmlProvider;
        private itemProvider;
        public filterPopupViewModel: TGrid.IFilterPopupViewModel;
        public options: TGrid.Options;
        private firstVisibleItemIndex;
        private totalItemsCount;
        private previousPage;
        private nextPage;
        private visibleItems;
        private visibleViewModels;
        private isPreloadingNext;
        private isPreloadingPrevious;
        private footerViewModel;
        private collapsedGroupFilterDescriptors;
        private enablePreload;
        private manualScrollTimeoutToken;
        private isBuisy;
        constructor(element: HTMLElement, options: TGrid.Options, provider: TGrid.IItemProvider);
        static getGridObject(element: HTMLElement): Grid;
        public columnsResized(c: TGrid.ColumnInfo): void;
        private mouseWheel(e);
        private keyPress(e);
        private selectNextItem();
        private selectPreviousItem();
        private getPreviousPageFirsItemIndex();
        private isDesktopMode();
        private getPreviousPageSize();
        private getNextPageFirstItemIndex();
        private getNextPageSize();
        private getEffectiveSorting();
        private getEffectiveFiltering();
        private getCollapsedGroupFilter();
        public scrollTable(): void;
        private updateGlobalScroll();
        private updateGlobalScrollMobile();
        private onManualScroll();
        private preloadPreviousPage();
        private preloadNextPage();
        private showPreviousPage();
        private showNextPage();
        private scrollTableContainer(scrollTop);
        private silentScrollTableContainer(scrollTop);
        public addGroupDescriptor(name: string, asc: boolean): void;
        public toggleGroupDescriptor(name: string): void;
        public removeGroupDescriptor(path: string): void;
        public showFilterPopup(column: TGrid.ColumnInfo, pageX: number, pageY: number, isForDesktop: boolean): void;
        public hideFilterPopup(): void;
        public sortBy(name: string): void;
        public mobileSortBy(name: string, asc: boolean): void;
        public selectPage(page: number): void;
        public selectItem(item: TGrid.ItemViewModel, multi: boolean): boolean;
        public scrollIntoView(item: any): void;
        public updateRow(item: any, shouldAddDetails: boolean): void;
        private buildViewModels(items);
        private isEqualOrDeeperThanCollapsedFilter(collapsedFilter, filter);
        private isGroupCollapsedOrInsideCollapsed(filterDescriptor);
        private updateVisibleItems();
        private getHtmlProvider(options);
        private getFirstItemNumber();
        private getPageSize();
        private refreshHeader();
        public updateBody(): void;
        private refreshBody(withBuisy?);
        private refreshFooter();
        private updateFooterViewModel();
        private showBuisyIndicator();
        private hideBuisyIndicator();
        public setCollapsedFilters(filterDescriptor: TGrid.FilterDescriptor): void;
        public removeCollapsedFilters(filterDescriptor: TGrid.FilterDescriptor): void;
        public applyFilters(): void;
        private refreshMobileHeader();
        public afterOptionsChange(): void;
    }
}
