/// <reference path="IHtmlProvider.d.ts" />
/// <reference path="ItemViewModel.d.ts" />
/// <reference path="IFooterViewModel.d.ts" />
/// <reference path="IFilterPopupViewModel.d.ts" />
declare module TesserisPro.TGrid {
    class BaseHtmlProvider implements TGrid.IHtmlProvider {
        static oldOnClick: (ev: MouseEvent) => any;
        public getTableElement(option: TGrid.Options): HTMLElement;
        public bindData(option: TGrid.Options, elementForBinding: HTMLElement): void;
        public getElementsSize(container: HTMLElement, items: TGrid.ItemViewModel[]): number;
        public getFirstVisibleItem(container: HTMLElement, items: TGrid.ItemViewModel[], scrollTop: number): TGrid.ItemViewModel;
        public getVisibleItemsCount(container: HTMLElement, view: HTMLElement, items: TGrid.ItemViewModel[], scrollTop: number): number;
        public getFooterViewModel(grid: any): void;
        public getFilterPopupViewModel(container: HTMLElement): void;
        public updateTableHeadElement(option: TGrid.Options, header: HTMLElement, groupByContainer: HTMLElement, filterPopupContainer: HTMLElement, columnsResized: (c: TGrid.ColumnInfo) => void): void;
        public updateTableBodyElement(option: TGrid.Options, container: HTMLElement, items: TGrid.ItemViewModel[], selected: (item: TGrid.ItemViewModel, multi: boolean) => boolean): void;
        public updateTableFooterElement(option: TGrid.Options, footer: HTMLElement, totalItemsCount: number, footerModel: TGrid.IFooterViewModel): void;
        public updateGroupedTableBodyElement(option: TGrid.Options, container: HTMLElement, items: TGrid.ItemViewModel[], selected: (item: TGrid.ItemViewModel, multi: boolean) => boolean): void;
        public updateColumnWidth(option: TGrid.Options, header: HTMLElement, body: HTMLElement, footer: HTMLElement): void;
        public buildDefaultTableFooterElement(option: TGrid.Options, footer: HTMLElement, totalItemsCount: number): void;
        public getActualDetailsTemplate(option: TGrid.Options): TGrid.Template;
        public updateTableDetailRow(option: TGrid.Options, container: HTMLElement, item: TGrid.ItemViewModel, shouldAddDetails: boolean): void;
        public updateMobileDetailRow(option: TGrid.Options, container: HTMLElement, item: TGrid.ItemViewModel, shouldAddDetails: boolean): void;
        public buildDefaultHeader(container: HTMLElement, headerName: string): void;
        public onCloseFilterPopup(): void;
        public updateGroupByPanel(option: TGrid.Options, groupByPanel: HTMLElement): void;
        public showNeededIndents(target: HTMLElement, level: number, grid: TGrid.Grid): void;
        public updateFilteringPopUp(option: TGrid.Options, filterPopup: HTMLElement, filterPopupModel: TGrid.IFilterPopupViewModel): void;
        private addActualGroupByElements(option, groupByContainer);
        private updateGroupByMenuContent(option, menu);
        public buildGroupMobileHeaderRow(option: TGrid.Options, groupHeaderDescriptor: TGrid.GroupHeaderDescriptor): HTMLElement;
        public bindMobileGroupHeader(headerContainer: HTMLElement, item: any, headerDiv: HTMLElement): void;
        public createDefaultGroupHeader(tableRowElement: any): void;
        public addFilterButton(option: TGrid.Options, header: HTMLElement, filterPopupContainer: HTMLElement, headerButtons: HTMLElement, culumnNumber: number): void;
        public updateMobileHeadElement(option: TGrid.Options, mobileHeader: HTMLElement, filterPopupContainer: HTMLElement): void;
        public updateMobileItemsList(option: TGrid.Options, container: HTMLElement, items: TGrid.ItemViewModel[], selected: (item: TGrid.ItemViewModel, multi: boolean) => boolean): void;
        public createMobileButton(option: TGrid.Options, mobileHeader: HTMLElement, filterPopUp: HTMLElement): void;
        private addMobileMenuItems(option, menu, filterPopUp);
        public doOnClickOutside(target: HTMLElement, action: () => void): void;
        public appendIndent(target: HTMLElement, level: number, isHeader: boolean): void;
        private buildColumnHeader(column);
        private buildMobileMenuColumnHeader(column);
        private anyConditionIsApplied(options);
        private detachDocumentClickEvent();
    }
}
