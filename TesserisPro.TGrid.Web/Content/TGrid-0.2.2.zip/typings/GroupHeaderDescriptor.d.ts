declare module TesserisPro.TGrid {
    class GroupHeaderDescriptor {
        public value: string;
        public level: number;
        public collapse: boolean;
        public filterDescriptor: TGrid.FilterDescriptor;
        constructor(value: string, level: number, collapse: boolean, filterDescriptor: TGrid.FilterDescriptor);
    }
}
