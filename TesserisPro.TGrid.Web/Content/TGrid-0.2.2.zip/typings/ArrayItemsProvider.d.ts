/// <reference path="SortDescriptor.d.ts" />
/// <reference path="FilterDescriptor.d.ts" />
declare module TesserisPro.TGrid {
    class ArrayItemsProvider implements TGrid.IItemProvider {
        private sourceItems;
        public actionAfterAddingItem: () => void;
        public actionAfterDeletingItem: () => void;
        constructor(items: any[]);
        public getItems(firstItem: number, itemsNumber: number, sortDescriptors: TGrid.SortDescriptor[], filterDescriptor: TGrid.FilterDescriptor, collapsedFilterDescriptors: TGrid.FilterDescriptor[], callback: (items: any[], firstItem: number, itemsNumber: number) => void): void;
        public getTotalItemsCount(filterDescriptor: TGrid.FilterDescriptor, callback: (total: number) => void): void;
        public addItem(item: any): void;
        public deleteItem(item: any): void;
        private sort(items, sortDescriptors);
        private compareRecursive(a, b, sortDescriptors, i);
        private sortingOrder(sortDescriptor);
        private sortingOrderDesc(sortDescriptor);
        private filter(items, filterDescriptor, collapsedFilterDescriptors);
        private isFilterSatisfied(item, filterDescriptor);
        private isChildFiltersSatisfied(item, filterDescriptor);
        private isFilterConditionSatisfied(item, value, condition);
    }
}
