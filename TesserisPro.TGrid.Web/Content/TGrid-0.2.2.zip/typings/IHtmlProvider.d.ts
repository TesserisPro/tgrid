/// <reference path="Options.d.ts" />
/// <reference path="ItemViewModel.d.ts" />
/// <reference path="IFooterViewModel.d.ts" />
declare module TesserisPro.TGrid {
    interface IHtmlProvider {
        getElementsSize(container: HTMLElement, items: any[]): number;
        getFirstVisibleItem(container: HTMLElement, items: TGrid.ItemViewModel[], scrollTop: number): TGrid.ItemViewModel;
        getVisibleItemsCount(container: HTMLElement, view: HTMLElement, items: TGrid.ItemViewModel[], scrollTop: number): number;
        getFooterViewModel(grid: any): any;
        getFilterPopupViewModel(container: HTMLElement): any;
        getTableElement(option: TGrid.Options): HTMLElement;
        updateTableHeadElement(option: TGrid.Options, header: HTMLElement, groupByContainer: HTMLElement, filterPopupContainer: HTMLElement, columnsResized: (c: TGrid.ColumnInfo) => void): any;
        updateTableBodyElement(option: TGrid.Options, body: HTMLElement, items: TGrid.ItemViewModel[], selected: (item: TGrid.ItemViewModel, multi: boolean) => boolean): void;
        updateTableFooterElement(option: TGrid.Options, footer: HTMLElement, totalItemsCount: number, footerModel: TGrid.IFooterViewModel): void;
        updateMobileItemsList(option: TGrid.Options, container: HTMLElement, items: TGrid.ItemViewModel[], selected: (item: TGrid.ItemViewModel, multi: boolean) => boolean): void;
        updateMobileHeadElement(option: TGrid.Options, mobileHeader: HTMLElement, filterPopupContainer: HTMLElement): void;
        updateTableDetailRow(option: TGrid.Options, container: HTMLElement, item: TGrid.ItemViewModel, shouldAddDetails: boolean): void;
        updateMobileDetailRow(option: TGrid.Options, container: HTMLElement, item: TGrid.ItemViewModel, shouldAddDetails: boolean): void;
        updateFilteringPopUp(option: TGrid.Options, filterPopupContainer: HTMLElement, filterPopupModel: TGrid.IFilterPopupViewModel): void;
        updateColumnWidth(option: TGrid.Options, header: HTMLElement, body: HTMLElement, footer: HTMLElement): void;
    }
}
