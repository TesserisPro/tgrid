declare module TesserisPro.TGrid {
    class SortDescriptor {
        constructor(path: string, asc: boolean);
        public path: string;
        public asc: boolean;
    }
}
