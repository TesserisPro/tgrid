declare module TesserisPro.TGrid {
    class ItemViewModel {
        public model: any;
        public item: any;
        public grid: any;
        public isGroupHeader: boolean;
        constructor(model: any, item: any, grid: any, isGroupHeader: boolean);
        public toggleDetailsForCell(columnIndex: any): void;
        public openDetailsForCell(columnIndex: any): void;
        public closeDetailsForCell(columnIndex: any): void;
        public setItemValue(item: any): void;
        public addItem(item: any): void;
        public deleteItem(item: any): void;
    }
}
