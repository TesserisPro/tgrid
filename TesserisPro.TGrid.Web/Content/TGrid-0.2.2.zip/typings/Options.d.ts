﻿/// <reference path="SortDescriptor.d.ts" />
/// <reference path="FilterDescriptor.d.ts" />
declare module TesserisPro.TGrid {
    enum Framework {
        Knockout = 0,
        Angular = 1,
    }
    enum SelectionMode {
        None = 0,
        Single = 1,
        Multi = 2,
    }
    enum FilterCondition {
        None = 0,
        Equals = 1,
        NotEquals = 2,
    }
    enum LogicalOperator {
        And = 0,
        Or = 1,
    }
    class ColumnInfo {
        public header: Template;
        public cell: Template;
        public cellDetail: Template;
        public width: string;
        public device: string;
        public sortMemberPath: string;
        public groupMemberPath: string;
        public member: string;
        public resizable: boolean;
        public filterMemberPath: string;
    }
    class ShowDetail {
        public item: any;
        public column: number;
        constructor();
    }
    class Template {
        private content;
        constructor(prototype: HTMLElement);
        public applyTemplate(element: HTMLElement): void;
        public getContent(): string;
    }
    class Options {
        public columns: ColumnInfo[];
        public enableVirtualScroll: boolean;
        public enablePaging: boolean;
        public enableCollapsing: boolean;
        public enableSorting: boolean;
        public enableGrouping: boolean;
        public enableFiltering: boolean;
        public filterPath: string;
        public mobileTemplateHtml: Template;
        public detailsTemplateHtml: Template;
        public groupHeaderTemplate: Template;
        public filterPopup: Template;
        public framework: Framework;
        public target: HTMLElement;
        public pageSize: number;
        public pageSlide: number;
        public batchSize: number;
        public firstLoadSize: number;
        public currentPage: number;
        public sortDescriptor: TGrid.SortDescriptor;
        public groupBySortDescriptors: TGrid.SortDescriptor[];
        public selectionMode: SelectionMode;
        public openDetailsOnSelection: boolean;
        public filterDescriptor: TGrid.FilterDescriptor;
        public tableFooterTemplate: Template;
        public showDetailFor: ShowDetail;
        public selection: any[];
        public shouldAddDetailsOnSelection: boolean;
        public showCustomDetailFor: ShowDetail;
        public parentViewModel: any;
        public filterPopupForColumn: ColumnInfo;
        public columnMinWidth: number;
        public apply: () => void;
        constructor(element: HTMLElement, framework: Framework);
        public isSelected(item: any): boolean;
        private initialize();
        public applyHandler(): void;
    }
}
