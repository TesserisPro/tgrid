declare module TesserisPro.TGrid {
    class FilterDescriptor {
        public path: string;
        public value: string;
        public condition: TGrid.FilterCondition;
        public children: FilterDescriptor[];
        public parentChildUnionOperator: TGrid.LogicalOperator;
        public childrenUnionOperator: TGrid.LogicalOperator;
        constructor(path: string, values: string, condition: TGrid.FilterCondition, parentChildOperator?: TGrid.LogicalOperator, childOperator?: TGrid.LogicalOperator, children?: FilterDescriptor[]);
        public addChild(filter: FilterDescriptor): void;
        public removeChildByPath(path: string): void;
        static getEmpty(): FilterDescriptor;
    }
}
