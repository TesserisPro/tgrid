declare module TesserisPro.TGrid {
    interface IFooterViewModel {
        setTotalCount(totalCount: number): any;
        setSelectedItem(selectedItem: any): any;
        setCurrentPage(currentPage: number): any;
        setTotalPages(totalPages: number): any;
        changePage(pageNumber: number): any;
        goToPreviousPagesBlock(): any;
        goToNextPagesBlock(): any;
        goToFirstPage(): any;
        goToLastPage(): any;
    }
}
