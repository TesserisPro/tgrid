/// <reference path="SortDescriptor.d.ts" />
/// <reference path="FilterDescriptor.d.ts" />
declare module TesserisPro.TGrid {
    class ServerItemsProvider implements TGrid.IItemProvider {
        private urlGetItems;
        private urlGetTotalNumber;
        private items;
        private path;
        public actionAfterAddingItem: () => void;
        public actionAfterDeletingItem: () => void;
        constructor(urlGetItems: string, urlGetTotalNumber: string, path: string);
        public getItems(firstItem: number, itemsNumber: number, sortDescriptors: TGrid.SortDescriptor[], filterDescriptors: TGrid.FilterDescriptor, collapsedFilterDescriptors: TGrid.FilterDescriptor[], callback: (items: any[], firstItem: number, itemsNumber: number) => void): void;
        public getTotalItemsCount(filterDescriptors: TGrid.FilterDescriptor, callback: (total: number) => void): void;
        public deleteItem(item: any): void;
        public addItem(item: any): void;
    }
}
